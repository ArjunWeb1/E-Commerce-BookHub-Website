// backend/server.js
import express from 'express';
import mongoose from 'mongoose';
import cors from 'cors';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';



const app = express();
app.use(cors());
app.use(express.json());

// MongoDB Connection
mongoose.connect('mongodb://localhost/ecommerce', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
}).then(() => console.log('Connected to MongoDB'))
  .catch(err => console.log('Error connecting to MongoDB:', err));

// Models for User and Cart
const User = mongoose.model('User', new mongoose.Schema({
  email: String,
  password: String
}));

const Cart = mongoose.model('Cart', new mongoose.Schema({
  userId: String,
  products: [{ productId: String, quantity: Number }]
}));

// Register User Route
app.post('/api/register', async (req, res) => {
  const { email, password } = req.body;
  const hashedPassword = await bcrypt.hash(password, 10);
  const newUser = new User({ email, password: hashedPassword });
  await newUser.save();
  res.status(201).send('User Registered');
});

// Login Route
app.post('/api/login', async (req, res) => {
  const { email, password } = req.body;
  const user = await User.findOne({ email });

  if (!user) return res.status(404).send('User not found');
  
  const match = await bcrypt.compare(password, user.password);
  if (!match) return res.status(400).send('Invalid credentials');
  
  const token = jwt.sign({ userId: user._id }, process.env.JWT_SECRET, { expiresIn: '1h' });
  res.json({ token });
});

// Middleware to verify token
const authenticateToken = (req, res, next) => {
  const token = req.headers['authorization'];
  if (!token) return res.status(403).send('Access denied');
  
  jwt.verify(token, process.env.JWT_SECRET, (err, user) => {
    if (err) return res.status(403).send('Invalid token');
    req.user = user;
    next();
  });
};

// Add to Cart Route
app.post('/api/cart', authenticateToken, async (req, res) => {
  const { productId, quantity } = req.body;
  const cart = await Cart.findOne({ userId: req.user.userId });

  if (cart) {
    // Check if product exists in cart and update quantity
    const productIndex = cart.products.findIndex(p => p.productId === productId);
    if (productIndex > -1) {
      cart.products[productIndex].quantity += quantity;
    } else {
      cart.products.push({ productId, quantity });
    }
    await cart.save();
  } else {
    const newCart = new Cart({ userId: req.user.userId, products: [{ productId, quantity }] });
    await newCart.save();
  }
  res.status(200).send('Product added to cart');
});

// Get Cart Route
app.get('/api/cart', authenticateToken, async (req, res) => {
  const cart = await Cart.findOne({ userId: req.user.userId });
  if (!cart) return res.status(404).send('Cart not found');
  res.json(cart);
});

// Delete from Cart Route
app.delete('/api/cart/:productId', authenticateToken, async (req, res) => {
  const cart = await Cart.findOne({ userId: req.user.userId });
  if (!cart) return res.status(404).send('Cart not found');

  const productIndex = cart.products.findIndex(p => p.productId === req.params.productId);
  if (productIndex > -1) {
    cart.products.splice(productIndex, 1);
    await cart.save();
    res.status(200).send('Product removed from cart');
  } else {
    res.status(404).send('Product not found in cart');
  }
});

// Fetch Books Route (Simulating a book list or fetch from OpenLibrary API)
app.get('/api/books', async (req, res) => {
  const books = [
    { id: '1', title: 'React for Beginners', author: 'John Doe', price: 19.99 },
    { id: '2', title: 'Learning React', author: 'Jane Smith', price: 29.99 },
    { id: '3', title: 'JavaScript Essentials', author: 'David Green', price: 24.99 },
    { id: '4', title: 'Advanced React', author: 'Sam White', price: 39.99 },
    { id: '5', title: 'Frontend Development', author: 'Rachel Black', price: 14.99 },
  ];
  res.json(books);
});

// Start Server
app.listen(5000, () => {
  console.log('Backend server is running on http://localhost:5000');
});
